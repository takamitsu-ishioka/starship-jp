#!/bin/bash

cd "`dirname $0`"

#source ~/bin/config.sh
source ./config.sh

lastlog="$(ls -1 ./logs | tail -1)"

if [ "$lastlog" = '' ]; then
    log 'No log files found'
    exit 1
fi

less -M "./logs/$lastlog"
