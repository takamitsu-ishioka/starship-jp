
export interface MedicalHistoryProps {
  id?: number
  name: string
  flag: boolean
}

export class MedicalHistory {
  public id?: number
  public name: string
  public flag: boolean

  constructor(init: MedicalHistoryProps) {
    this.id = init.id
    this.name = init.name
    this.flag = init.flag
  }
}