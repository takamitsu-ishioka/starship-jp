import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import { RecoilRoot } from 'recoil'
import {
  createBrowserRouter,
  RouterProvider
} from 'react-router-dom'
import CssBaseline from '@mui/material/CssBaseline';
import { PatientList } from './patient/PatientList.tsx'
import { PatientDetail } from './patient/PatientDetail.tsx'

const router = createBrowserRouter([
  {
    element: <App />,
    children: [
      {
        path: '/',
        element: <PatientList />
      },
      {
        path: 'patient/:id',
        element: <PatientDetail />
      },
    ]
  }
])

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <RecoilRoot>
      <CssBaseline />
      <RouterProvider router={router} />
    </RecoilRoot>
  </React.StrictMode>,
)
