import { useState } from 'react';
import { useRecoilValue, useRecoilState } from "recoil";
import { useParams } from "react-router-dom";
import {
  Box,
  Grid,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  Button,
} from "@mui/material";
import IconButton from '@mui/material/IconButton';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import EditIcon from '@mui/icons-material/Edit';
import Tooltip from '@mui/material/Tooltip';
import AddIcon from '@mui/icons-material/Add';

import { MedicalHistory } from '../models/MedicalHistory';
import { Medicine } from '../models/Medicine';
import {
  patientDetailState,
  useCreateMedicalHistory,
  useDeleteMedicalHistory,
  useCreateMedicine,
  useDeleteMedicine,
} from "../states/PatientDetailState";

export function PatientDetail() {
  const { id } = useParams();
  const patient = useRecoilValue(patientDetailState(id));
  console.log(patient);

  // START 病歴の追加
  const [openMedicalHistoryDialog, setOpenMedicalHistoryDialog] = useState(false);
  const onCreateMedicalHistoryClicked = () => {
    setOpenMedicalHistoryDialog(true);
  };
  const closeMedicalHistoryDialog = () => {
    setOpenMedicalHistoryDialog(false);
  };
  const createMedicalHistory = useCreateMedicalHistory();
  const onCreateMedicalHistory = (medicalHistory: MedicalHistory) => {
    if (id === undefined) {
      alert('患者 id がありません') // これはありえない
      return
    }
    createMedicalHistory(id, medicalHistory)
    closeMedicalHistoryDialog();
  };
  // END 病歴の追加

  // START 病歴の削除
  const [openDeleteMedicalHistoryDialog, setOpenDeleteMedicalHistoryDialog] = useState(false);
  const [selectedMedicalHistoryId, setSelectedMedicalHistoryId] = useState<number | undefined>();
  const [selectedMedicalHistoryName, setSelectedMedicalHistoryName] = useState<string | undefined>();
  const onDeleteMedicalHistoryClicked = (mh: MedicalHistory) => {
    setSelectedMedicalHistoryId(mh.id);
    setSelectedMedicalHistoryName(mh.name);
    setOpenDeleteMedicalHistoryDialog(true);
  };
  const closeDeleteMedicalHistoryDialog = () => {
    setOpenDeleteMedicalHistoryDialog(false);
  };
  const [, setPatient] = useRecoilState(patientDetailState(id));
  const deleteMedicalHistory = useDeleteMedicalHistory();
  const onDeleteMedicalHistoryDialogOKClicked = () => {
    if (id !== undefined && selectedMedicalHistoryId !== undefined) {
      deleteMedicalHistory(Number(id), selectedMedicalHistoryId)
      setSelectedMedicalHistoryId(undefined);
      setSelectedMedicalHistoryName(undefined)
      closeDeleteMedicalHistoryDialog();
      setPatient((prevPatient) => ({
        ...prevPatient,
        medicalHistories: (prevPatient.medicalHistories || []).filter(mh => mh.id !== selectedMedicalHistoryId),
      }));
    }
  };
  // END 病歴の削除

  // START 薬歴の追加
  const [openMedicineDialog, setOpenMedicineDialog] = useState(false);
  const onCreateMedicineClicked = () => {
    setOpenMedicineDialog(true);
  };
  const closeMedicineDialog = () => {
    setOpenMedicineDialog(false);
  };
  const createMedicine = useCreateMedicine();
  const onCreateMedicine = (medicine: Medicine) => {
    if (id === undefined) {
      alert('患者 id がありません') // これはありえない
      return
    }
    createMedicine(id, medicine)
    closeMedicineDialog();
  };
  // END 薬歴の追加

  // START 薬歴の削除
  const [openDeleteMedicineDialog, setOpenDeleteMedicineDialog] = useState(false);
  const [selectedMedicineId, setSelectedMedicineId] = useState<number | undefined>();
  const [selectedMedicineName, setSelectedMedicineName] = useState<string | undefined>();
  const onDeleteMedicineClicked = (medicine: Medicine) => {
    setSelectedMedicineId(medicine.id);
    setSelectedMedicineName(medicine.name);
    setOpenDeleteMedicineDialog(true);
  };
  const closeDeleteMedicineDialog = () => {
    setOpenDeleteMedicineDialog(false);
  };
  const deleteMedicine = useDeleteMedicine();
  const onDeleteMedicineDialogOKClicked = () => {
    if (id !== undefined && selectedMedicineId !== undefined) {
      deleteMedicine(Number(id), selectedMedicineId)
      setSelectedMedicineId(undefined);
      setSelectedMedicineName(undefined);
      closeDeleteMedicineDialog();
      setPatient((prevPatient) => ({
        ...prevPatient,
        medicines: (prevPatient.medicines || []).filter(medicine => medicine.id !== selectedMedicineId),
      }));
    }
  };
  // END 薬歴の削除

  return (
    <Box sx={{mt: 3}}>
      <Typography variant="h3">{patient.name}</Typography>
      <Typography variant="body1">主訴：{patient.complaint}</Typography>
      <Grid container spacing={2}>
        <Grid item xs={6}>
          <TableContainer component={Paper}>
            <Table>{ /* DONE: Table を挿入 */ }
              <TableHead>
                <TableRow>
                  <TableCell>病歴</TableCell>
                  <TableCell>有無</TableCell>
                  <TableCell>操作</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                  {patient.medicalHistories?.map((mh, index) => { // DONE: index 追加
                    return (
                      <TableRow key={index}>{ /* DONE: key 追加 */ }
                        <TableCell>{mh.name}</TableCell>
                        <TableCell>{mh.flag ? "あり" : "なし"}</TableCell>
                        <TableCell>
                          <Tooltip title="編集">
                            <IconButton color="primary" aria-label="edit">
                              <EditIcon />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="削除">
                            <IconButton color="secondary" aria-label="delete" onClick={() => onDeleteMedicalHistoryClicked(mh)}>
                              <DeleteOutlineIcon />
                            </IconButton>
                          </Tooltip>
                          <Dialog
                            open={openDeleteMedicalHistoryDialog}
                            onClose={closeDeleteMedicalHistoryDialog}
                            fullWidth={true}
                            maxWidth="sm"
                            componentsProps={{
                              backdrop: {
                                style: {
                                  backgroundColor: 'transparent',
                                },
                              },
                            }}
                          >
                            <DialogTitle>病歴の削除</DialogTitle>
                            <DialogContent>
                              <DialogContentText>【{`${selectedMedicalHistoryName}`}】の病歴を削除してもよろしいですか？</DialogContentText>
                            </DialogContent>
                            <DialogActions>
                              <Button onClick={closeDeleteMedicalHistoryDialog}>キャンセル</Button>
                              <Button onClick={onDeleteMedicalHistoryDialogOKClicked} color="secondary">OK</Button>
                            </DialogActions>
                          </Dialog>
                        </TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            </Table>
          </TableContainer>
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            sx={{ mt: 2 }}
            onClick={onCreateMedicalHistoryClicked}
          >
            病歴を追加
          </Button>
          {/* 病歴作成ダイアログ */}
          <CreateMedicalHistoryDialog
            open={openMedicalHistoryDialog}
            onClose={closeMedicalHistoryDialog}
            onCreate={onCreateMedicalHistory}
          />
        </Grid>
        <Grid item xs={6}>
          <TableContainer component={Paper}>
            <Table>{ /* DONE: Table を挿入 */ }
              <TableHead>
                <TableRow>
                  <TableCell>薬歴</TableCell>
                  <TableCell>操作</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                  {patient.medicines?.map((m, index) => { // DONE: index 追加
                    return (
                      <TableRow key={index}>{ /* DONE: key 追加 */ }
                        <TableCell>{m.name}</TableCell>
                        <TableCell>
                          <Tooltip title="編集">
                            <IconButton color="primary" aria-label="edit">
                              <EditIcon />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="削除">
                            <IconButton color="secondary" aria-label="delete" onClick={() => onDeleteMedicineClicked(m)}>
                              <DeleteOutlineIcon />
                            </IconButton>
                          </Tooltip>
                          <Dialog
                            open={openDeleteMedicineDialog}
                            onClose={closeDeleteMedicineDialog}
                            fullWidth={true}
                            maxWidth="sm"
                            componentsProps={{
                              backdrop: {
                                style: {
                                  backgroundColor: 'transparent',
                                },
                              },
                            }}
                          >
                            <DialogTitle>薬歴の削除</DialogTitle>
                            <DialogContent>
                              <DialogContentText>【{`${selectedMedicineName}`}】の薬歴を削除してもよろしいですか？</DialogContentText>
                            </DialogContent>
                            <DialogActions>
                              <Button onClick={closeDeleteMedicineDialog}>キャンセル</Button>
                              <Button onClick={onDeleteMedicineDialogOKClicked} color="secondary">OK</Button>
                            </DialogActions>
                          </Dialog>
                        </TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            </Table>
          </TableContainer>
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            sx={{ mt: 2 }}
            onClick={onCreateMedicineClicked}
          >
            薬歴を追加
          </Button>
          {/* 薬歴作成ダイアログ */}
          <CreateMedicineDialog
            open={openMedicineDialog}
            onClose={closeMedicineDialog}
            onCreate={onCreateMedicine}
          />
        </Grid>
      </Grid>
    </Box>
  );
}

import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  FormControl,
  FormLabel,
  TextField,
  RadioGroup,
  FormControlLabel,
  Radio,
} from "@mui/material";

interface CreateMedicalHistoryDialogProps {
  open: boolean;
  onClose: () => void;
  onCreate: (medicalHistory: MedicalHistory) => void;
}

export function CreateMedicalHistoryDialog({ open, onClose, onCreate: onCreate }: CreateMedicalHistoryDialogProps) {
  const [name, setName] = useState('');
  const [flag, setFlag] = useState('あり'); // 初期値を「あり」に設定

  const onCreateMedicalHistoryDialogOKClicked = () => {
    onCreate({ name, flag: flag === 'あり' });
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle>病歴の追加</DialogTitle>
      <DialogContent>
        <TextField
          autoFocus
          margin="dense"
          id="name"
          label="病歴名"
          type="text"
          fullWidth
          variant="outlined"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <FormControl component="fieldset" margin="normal">
          <FormLabel component="legend">病歴の有無</FormLabel>
          <RadioGroup
            aria-label="flag"
            name="flag"
            value={flag}
            onChange={(e) => setFlag(e.target.value)}
          >
            <FormControlLabel value="あり" control={<Radio />} label="あり" />
            <FormControlLabel value="なし" control={<Radio />} label="なし" />
          </RadioGroup>
        </FormControl>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>キャンセル</Button>
        <Button color="secondary" onClick={onCreateMedicalHistoryDialogOKClicked}>OK</Button>
      </DialogActions>
    </Dialog>
  );
}

interface CreateMedicineDialogProps {
  open: boolean;
  onClose: () => void;
  onCreate: (medicine: Medicine) => void;
}

export function CreateMedicineDialog({ open, onClose, onCreate }: CreateMedicineDialogProps) {
  const [name, setName] = useState('');

  const onCreateMedicineDialogOKClicked = () => {
    onCreate({ name });
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle>薬歴の追加</DialogTitle>
      <DialogContent>
        <TextField
          autoFocus
          margin="dense"
          id="name"
          label="薬歴名"
          type="text"
          fullWidth
          variant="outlined"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>キャンセル</Button>
        <Button color="secondary" onClick={onCreateMedicineDialogOKClicked}>OK</Button>
      </DialogActions>
    </Dialog>
  );
}
