import axios from "axios";
import { atom, selector } from "recoil";
import { Patient, PatientProps } from '../models/Patient'
import { HOSTNAME } from "./Common";

const ENDPOINT_LIST= `${HOSTNAME}/v1/list`

export const patientsListSelector = selector({
  key: 'patientsListSelector',
  get: async () => {

    const response = await axios.get(ENDPOINT_LIST)
    const items = response.data as Array<any>

    const patients = items.map((v) => {
      const p = v as PatientProps
      return new Patient({
        id: p.id,
        name: p.name,
        complaint: p.complaint
      })
    })
    return patients    
  }
})

export const patientsListState = atom({
  key: 'patientsListState',
  default: patientsListSelector
})