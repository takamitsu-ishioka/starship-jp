import { useRecoilValue } from "recoil"
import { patientsListState } from "../states/PatientsListState"
import { Avatar, Divider, List, ListItem, ListItemAvatar, ListItemText, Button } from "@mui/material"

export function PatientList() {
  const patients = useRecoilValue(patientsListState)
  return (
    <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
      {
        patients.map((p) => {
          return (
            <ListItem alignItems='flex-start'>
              <ListItemAvatar>
                <Avatar {...stringAvatar(p.name)} />

              </ListItemAvatar>
              <ListItemText 
                primary={p.name}
                secondary={p.complaint}
              />
              <Button variant="contained" href={'/patient/'+ p.id}>詳細</Button>
              <Divider variant="inset" component="li" />
            </ListItem>)
        })
      }
    </List>
  )
}

function stringAvatar(name: string) {
  return {
    sx: {
      bgcolor: stringToColor(name),
    },
    children: `${name[0]}`,
  };
}

function stringToColor(string: string) {
  let hash = 0;
  let i;

  /* eslint-disable no-bitwise */
  for (i = 0; i < string.length; i += 1) {
    hash = string.charCodeAt(i) + ((hash << 5) - hash);
  }

  let color = '#';

  for (i = 0; i < 3; i += 1) {
    const value = (hash >> (i * 8)) & 0xff;
    color += `00${value.toString(16)}`.slice(-2);
  }
  /* eslint-enable no-bitwise */

  return color;
}