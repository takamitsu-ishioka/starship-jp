
export interface MedicineProps {
  id?: number
  name: string
}

export class Medicine {
  public id?: number
  public name: string

  constructor(init: MedicineProps) {
    this.id = init.id
    this.name = init.name
  }
}