import os
import sqlite3
from flask import g

DATABASE = os.path.join(
  os.path.dirname(__file__),
  '..',
  'db',
  'db.sqlite3'
)

def get_db():
  db = getattr(g, '_db', None)
  if db is None:
    db = g._db = sqlite3.connect(DATABASE)
  return db
