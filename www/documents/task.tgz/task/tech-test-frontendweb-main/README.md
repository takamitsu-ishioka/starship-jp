# 技術課題用のfrontend(Web)

## 環境
- node: v20.11.0
- vite: ite/5.2.2
- yarn: 1.22.19

## 基本的な使い方
- 依存関係のインストール: yarn
- フロントエンドの起動: yarn dev
- http://localhost:4173/ にアクセス
- backendのflaskをport 5000で起動しておく必要があります
- https://github.com/TXPMedical/tech-test-backend

