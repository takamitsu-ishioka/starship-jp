import axios from "axios";
import { atomFamily, selectorFamily } from "recoil";
import { Patient } from '../models/Patient'
import { HOSTNAME } from "./Common";

const ENDPOINT_DETAIL= `${HOSTNAME}/v1/patient`

export const patientDetailSelector = selectorFamily({
  key: 'patientDetailSelector',
  get: param => async () => {

    const response = await axios.get(`${ENDPOINT_DETAIL}/${String(param)}`)

    const item = response.data

    const patient = new Patient({id: item.id, name: item.name, complaint: item.complaint})

    patient.medicalHistories = item.medical_histories
    patient.medicines = item.medicines

    return patient
  },
})

export const patientDetailState = atomFamily({
  key: 'patientDetailState',
  default: param => patientDetailSelector(param)
})

import { useRecoilCallback } from 'recoil';
import { AxiosError } from 'axios';
import { MedicalHistoryProps } from "../models/MedicalHistory";

const ENDPOINT_MEDICAL_HISTORY_CREATE = `${HOSTNAME}/v1/patient/medical_history/create`

export function useCreateMedicalHistory() {
  return useRecoilCallback(({set}) => async (patient_id: string, medicalHistory: MedicalHistoryProps) => {
    try {
      const requestBody = {
        patient_id: patient_id,
        medical_history: medicalHistory,
      }
      //const response = await axios.post(`${ENDPOINT_MEDICAL_HISTORY_CREATE}`, requestBody);
      const response = await axios.post(ENDPOINT_MEDICAL_HISTORY_CREATE, requestBody);
      const createdMedicalHistory = response.data
      console.log('>>>>>>> createdMedicalHistory:', createdMedicalHistory)
      set(
        patientDetailState(patient_id),
        (prevPatient) => {
          const prevMedicalHistories = prevPatient.medicalHistories ?? []
          const updatedPatient = {
            ...prevPatient,
            medicalHistories: [...prevMedicalHistories, createdMedicalHistory],
          }
          return updatedPatient
        }
      );
    } catch (error: unknown) {
      console.error("更新に失敗しました");
      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError;
        if (axiosError.response) {
          alert(JSON.stringify(axiosError.response.data, null, 4))
          console.log(axiosError.response.data);
          console.log(axiosError.response.status);
          console.log(axiosError.response.headers);
        }
      } else {
        console.error(error);
      }
    }
  });
}

const ENDPOINT_MEDICAL_HISTORY_DELETE = `${HOSTNAME}/v1/patient/medical_history/delete`

export function useDeleteMedicalHistory() {
  const deleteMedicalHistory = useRecoilCallback(({set}) => async (patientId: number, medicalHistoryId: number) => {
    try {
      const requestBody = {
        patient_id: patientId,
        medical_history_id: medicalHistoryId,
      }
      await axios.post(`${ENDPOINT_MEDICAL_HISTORY_DELETE}`, requestBody);
    } catch (error: unknown) {
      console.error("削除に失敗しました");
      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError;
        if (axiosError.response) {
          alert(JSON.stringify(axiosError.response.data, null, 4))
          console.log(axiosError.response.data);
          console.log(axiosError.response.status);
          console.log(axiosError.response.headers);
        }
      } else {
        console.error(error);
      }
    }
  });

  return deleteMedicalHistory;
}

import { MedicineProps } from "../models/Medicine";

const ENDPOINT_MEDICINE_CREATE = `${HOSTNAME}/v1/patient/medicine/create`

export function useCreateMedicine() {
  return useRecoilCallback(({set}) => async (patient_id: string, medicine: MedicineProps) => {
    try {
      const requestBody = {
        patient_id: patient_id,
        medicine: medicine,
      }
      const response = await axios.post(ENDPOINT_MEDICINE_CREATE, requestBody);
      const createdMedicine = response.data
      console.log('>>>>>>> createdMedicine:', createdMedicine)
      set(
        patientDetailState(patient_id),
        (prevPatient) => {
          const prevMedicines = prevPatient.medicines ?? []
          const updatedPatient = {
            ...prevPatient,
            medicines: [...prevMedicines, createdMedicine],
          }
          return updatedPatient
        }
      );
    } catch (error: unknown) {
      console.error("更新に失敗しました");
      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError;
        if (axiosError.response) {
          alert(JSON.stringify(axiosError.response.data, null, 4))
          console.log(axiosError.response.data);
          console.log(axiosError.response.status);
          console.log(axiosError.response.headers);
        }
      } else {
        console.error(error);
      }
    }
  });
}

const ENDPOINT_MEDICINE_DELETE = `${HOSTNAME}/v1/patient/medicine/delete`

export function useDeleteMedicine() {
  return useRecoilCallback(() => async (patientId: number, medicineId: number) => {
    try {
      const requestBody = {
        patient_id: patientId,
        medicine_id: medicineId,
      }
      await axios.post(ENDPOINT_MEDICINE_DELETE, requestBody);
    } catch (error: unknown) {
      console.error("薬歴の削除に失敗しました");
      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError;
        if (axiosError.response) {
          alert(JSON.stringify(axiosError.response.data, null, 4));
          console.log(axiosError.response.data);
          console.log(axiosError.response.status);
          console.log(axiosError.response.headers);
        }
      } else {
        console.error(error);
      }
    }
  });
}
