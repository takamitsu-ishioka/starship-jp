from typing import Optional
from lib.db import get_db
from lib.utils import bool_to_int
import logging

logging.basicConfig(level=logging.DEBUG)

class MedicalHistory:
  def __init__(self, name: str, flag: bool, id: Optional[int], user_id: Optional[int]) -> None:
    self.id = id
    self.user_id = user_id
    self.name = name
    self.flag = flag

  def __str__(self):
    return f"MedicalHistory(id={self.id} user_id={self.user_id} name={self.name}, flag={self.flag})"

  def dictionary(self):
    return {
      'id': self.id,
      'user_id': self.user_id,
      'name': self.name,
      'flag': self.flag
    }

  @classmethod
  def create(cls, patient_id: int, mh: dict):
    logging.debug(f"patient_id={patient_id}")
    logging.debug(f"json={mh}")
    db = get_db()
    cursor = db.cursor()

    try:
      result = cursor.execute(
        'INSERT INTO medical_history (user_id, name, flag) VALUES (?, ?, ?) RETURNING *',
        (patient_id, mh['name'], bool_to_int(mh['flag']))
      )
      row = result.fetchone()
      if not row:
        raise Exception(f"cannot insert medical_history: {mh}")
      # medical_history(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, name TEXT, flag BOOLEAN);
      id = row[0]
      user_id = row[1]
      name = row[2]
      flag = bool(row[3])
      # def __init__(self, name: str, flag: bool, id: Optional[int], user_id: Optional[int]) -> None:
      created_mh = MedicalHistory(name, flag, id, user_id)
      logging.debug(created_mh.dictionary())
      db.commit()
      return created_mh
    except KeyError as e:
      db.rollback()
      raise e
    except Exception as e:
      db.rollback()
      raise e

  @classmethod
  def delete(cls, patient_id: int, medical_history_id: int):
    logging.debug(f"patient_id={patient_id}")
    logging.debug(f"medical_history_id={medical_history_id}")
    db = get_db()
    cursor = db.cursor()

    try:
      cursor.execute(
        'UPDATE medical_history SET deleted = 1 WHERE id = ? AND user_id = ?',
        (medical_history_id, patient_id)
      )
      db.commit()
    except KeyError as e:
      db.rollback()
      raise e
    except Exception as e:
      db.rollback()
      raise e
