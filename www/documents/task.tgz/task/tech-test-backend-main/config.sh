#!/bin/bash

########################################################################
# このスクリプトの実行方法の判定

# bash コマンドで実行
# bash ./config.sh
# $0=./config.sh
# ${BASH_ARGV[0]}=

# 端末から source コマンドで実行
# source ./config.sh
# $0=-bash
# ${BASH_ARGV[0]}=./config.sh

# 他のスクリプトから source コマンドで実行
# ./install.sh
# $0=./install.sh
# ${BASH_ARGV[0]}=./config.sh

########################################################################
# 引数解釈

_verbose=0
_options=()
while [ 0 -lt $# ]
do
    arg="$1"
    if [[ "$arg" =~ ^- ]]; then
        opt="${arg:1}"
        if [[ "$opt" =~ ^v ]]; then
            _verbose=1
        fi
        _options=(${_options[@]} $arg)
        shift
    else
        break
    fi
done

########################################################################
# ファイルとディレクトリ

_cwd="`pwd`"
if [ "${BASH_ARGV[0]}" = '' ]; then
    _bin_dir="`dirname $0`"
    _script_path="$0"
    _env_dir="$_cwd"
elif [ "$0" = '-bash' ]; then
    _bin_dir="`dirname ${BASH_ARGV[0]}`"
    _script_path="${BASH_ARGV[0]}"
    _env_dir="$_cwd"
else
    _bin_dir="`dirname ${BASH_ARGV[0]}`"
    _script_path="$0"
    _env_dir="`dirname $_script_path`"
fi

########################################################################
# 共通関数ファイル読み込み

source "$_bin_dir/functions.sh"

########################################################################
# グローバル変数

_bin_dir="`get_absolute_path $_bin_dir`"
_script_path="`get_absolute_path $_script_path`"
_env_dir="`get_absolute_path $_env_dir`"
_script="`basename $_script_path`"
_absolute_script_dir="`dirname $_script_path`"
if [[ "$_env_dir" =~ -dev ]]; then
    _env_name='DEVELOPMENT'
    _isDev=1
elif [[ "$_env_dir" =~ -beta ]]; then
    _env_name='BETA'
    _isDev=0
else
    _env_name='RELEASE'
    _isDev=0
fi
_hostname=`hostname`
_ps_columns='user,pid,state,vsize,start,time,command'
_EXIT_CODE_SUCCESS=0
_EXIT_CODE_FAILURE=1
_EXIT_CODE_QUIT=255
_COLOR_WARNING_='\033[1;33m'
_COLOR_NORMAL_='\033[0;39m'
_mailto='ishioka@starship.jp'
_backup_dir='/home/ec2-user/backup'
_nttsmc_proj='smcgai'
_nttsmc_src="smcadmin@azure1.starship.jp:/home/smcadmin/projects/$_nttsmc_proj"

tty -s
if [ $? -eq 0 ]; then
    _isTty=1
else
    _isTty=0
fi

if [ $_verbose -eq 1 ]; then
    cat <<HERE 1>&2
_cwd: $_cwd
_bin_dir: $_bin_dir
_script_path: $_script_path
_env_dir: $_env_dir
_script: $_script
_absolute_script_dir: $_absolute_script_dir
_env_name: $_env_name
_isDev: $_isDev
_isTty: $_isTty
_hostname: $_hostname
HERE
fi
