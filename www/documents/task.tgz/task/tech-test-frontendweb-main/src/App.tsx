import { AppBar, Container, Toolbar, Typography, Button } from "@mui/material"
import React from "react"
import { Outlet } from "react-router-dom"

function App() {
  return (
    <Container>
      <AppBar position='static'>
        <Toolbar>
          <Typography variant="h6" component="div">
            <Button href='/' sx={{ my: 2, color: 'white', display: 'block' }}>Patient List</Button>
          </Typography>
        </Toolbar>
      </AppBar>
      <React.Suspense fallback={<div>Loading...</div>}>
          <Outlet />
      </React.Suspense>
    </Container>
  )
}

export default App
