//export const HOSTNAME = 'http://127.0.0.1:5000/'
export const HOSTNAME = 'http://txpmedical.starship.jp/api'
