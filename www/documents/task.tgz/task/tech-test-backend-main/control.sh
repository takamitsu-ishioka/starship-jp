#!/bin/bash

cd "`dirname $0`"

#source ~/bin/config.sh
source ./config.sh

function usage() {
    local message="$*"
    cat <<USAGE 1>&2
$_script: $message
usage: $_script [-v(erbose)] <subcommand>
subcommands:
     start: start flask
      stop: stop flask
    status: show flask status
USAGE
    exit 1
}

function start() {
    local pids=($(pgrep -f 'flask'))
    if [ ${#pids[@]} -ne 0 ]; then
        log "server already running"
        return 1
    fi
    if [ ! -d ./logs ]; then
        mkdir ./logs
        if [ $? -ne 0 ]; then
            log "can't mkdir ./logs"
            return 1
        fi
    fi
    local now="`date +'%Y-%m-%dT%H:%M:%S'`"
    local log_file="./logs/$now"
    flask --app main run > "$log_file" 2>&1 &
    sleep 1
    log "server started"
    local flask_pids=($(pgrep -f 'flask'))
    if [ ${#flask_pids[@]} -eq 0 ]; then
        log "can't start flask"
        return 1
    fi
    flask_pids="${flask_pids[@]}"
    flask_pids="${flask_pids// /,}"
    #echo2 "ps -p $flask_pids -o $_ps_columns"
    ps -p "$flask_pids" -o "$_ps_columns"
    return 0
}

function stop() {
    local pids=($(pgrep -f 'flask'))
    if [ ${#pids[@]} -eq 0 ]; then
        log "no flask processes found"
        return 1
    fi
    pids="${pids[@]}"
    local pid_csv="${pids// /,}"
    ps -p "$pid_csv" -o "$_ps_columns"
    log "kill -SIGINT $pids"
    #kill -SIGINT $pids バックグラウンドで実行すると、SIGINT では終了しない
    kill -SIGTERM $pids
    local max_trial_count=30
    local trial_count=0
    while [ 1 ]
    do
        sleep 1
        local pids_=($(pgrep -f 'flask'))
        if [ ${#pids_[@]} -eq 0 ]; then
            break
        fi
        pids_="${pids_[@]}"
        local pid_csv_="${pids_// /,}"
        ps -p "$pid_csv_" -o "$_ps_columns"
        let trial_count++
        if [ $trial_count -eq $max_trial_count ]; then
            log "can't kill $pids"
            return 1
        fi
    done
    log "killed $pids"
    return 0
}

function status() {
    local pids=($(pgrep -f 'flask'))
    if [ ${#pids[@]} -eq 0 ]; then
        log "no flask processes found"
        return 1
    fi
    pids="${pids[@]}"
    pids="${pids// /,}"
    ps -p "$pids" -o "$_ps_columns"
    return 0
}

if [ $# -lt 1 ]; then
    usage 'too few arguments'
fi

command="$1"
shift

if [ "$command" = 'start' ]; then
    start
elif [ "$command" = 'stop' ]; then
    stop
elif [ "$command" = 'status' ]; then
    status
else
    usage "unknown command $command"
fi

exit $?
