def bool_to_int(flag: bool) -> int:
    return 1 if flag else 0
