#!/bin/bash

cd "$(dirname "$0")"

#source ~/bin/config.sh
source ./config.sh

# 現在のブランチを取得
_current_branch=$(git rev-parse --abbrev-ref HEAD)
if [ $? -ne 0 ]; then
    log "can't fetch the current branch"
    exit 1
fi

# リモートのデフォルトブランチを取得
_origin_branch=$(git remote show origin | grep "HEAD branch" | cut -d ":" -f 2 | tr -d " ")
if [ $? -ne 0 ]; then
    log "can't fetch the default branch from origin"
    exit 1
fi

log "git diff origin/$_origin_branch..$_current_branch"
git diff origin/$_origin_branch..$_current_branch

exit 0
