#!/bin/bash
# 一般的関数

function send_alert_mail() {
    local body="$1"
    cat <<EOS | /usr/sbin/sendmail -t
From: $PROJECT_NAME <no-reply@$_hostname>
To: $SYSTEM_ALERT_MAILTO_CSV
Subject: Report from $_hostname
Content-Type: text/plain; charset=utf-8

$body
EOS
}

function send_alert_mail2() {
    local from="$1"
    local to_address_csv="$2"
    local subject="$3"
    local body="$4"
    cat <<EOS | /usr/sbin/sendmail -t
From: $from
To: $to_address_csv
Subject: $subject
Content-Type: text/plain; charset=utf-8

$body
EOS
}

# 最小 $1 最大 $2 の乱数を発生する
function random() {
    local min="$1"
    local max="$2"
    let local div=$max-$min+1
    let local num=$RANDOM%$div+$min
    echo $num
}

#  最大 $1 秒スリープするとき、2 つのプロセスのダウンタイム（$2 秒）が重なったら、そこまでの試行回数（＝日数）を返す
function get_collision_day() {
    local max_seconds=$1
    local down_time=$2
    local days=0
    while [ 1 ]
    do
        let days++
        local seconds1=`random 0 $max_seconds`
        local seconds2=`random 0 $max_seconds`
        #echo "$seconds1 $seconds2" 1>&2
        local before_start
        local after_start
        if [ $seconds1 -lt $seconds2 ]; then
            before_start=$seconds1
            after_start=$seconds2
        else
            before_start=$seconds2
            after_start=$seconds1
        fi
        let local before_end=$before_start+$down_time
        if [ $after_start -lt $before_end ]; then
            echo $days
            return
        fi
    done
}

#  最大 $1 秒スリープするとき、2 つのプロセスのダウンタイム（$2 秒）が、平均して何日目に衝突するか計算する
function get_average_collision_day() {
    local verbose=0
    if [[ "$1" =~ ^-v ]]; then
        verbose=1
        shift
    fi
    local max_seconds=$1
    local down_time=$2
    local total_day_count=0
    local test_count=0
    while [ $test_count -lt 100 ]
    do
        local day_count=`get_collision_day $max_seconds $down_time`
        let total_day_count+=$day_count
        let test_count++
        if [ $verbose -eq 1 ]; then
            echo "test $test_count" 1>&2
        fi
    done

    let average_collision_day_count=$total_day_count/$test_count

    echo $average_collision_day_count
}

#get_average_collision_day の使い方
#let max_seconds=60*60*2
#down_time=20
#day_count=`get_average_collision_day -v $max_seconds $down_time`
#echo $day_count

# ランダムに決められた秒数スリープする（cron の設定をホストごとに変えずに複数のホストでの同時実行を避ける。概ね避けられれば良い場合に使う）
function random_sleep() {
    local verbose=0
    local dry_run=0
    while [ 1 -lt $# ]
    do
        if [[ "$1" =~ ^-v ]]; then
            verbose=1
            shift
        elif [[ "$1" =~ ^-d ]]; then
            dry_run=1
            shift
        else
            echo "random_sleep: unknown option $1" 1>&2
            return 1
        fi
    done
    local max_seconds="$1"
    local seconds=`random 0 $max_seconds`
    if [ $verbose -eq 1 ]; then
        echo "sleeping $seconds seconds..." 1>&2
    fi
    if [ $dry_run -eq 0 ]; then
        sleep $seconds
    fi
    return 0
}

#random_sleep の使い方
#let max_seconds=60*60*2     # 最大 2 時間
#let max_seconds=30
#random_sleep -v -d $max_seconds    # 秒数を表示するだけ
#random_sleep -v $max_seconds       # 実際にスリープする
#ret=$?
#exit $ret

# 標準エラー出力に印字
function echo2() {
    local message="$*"
    echo "$message" 1>&2
}

# 標準エラー出力に印字（オプション指定可）
function echo2ex() {
    local options=()
    while [ 0 -eq 0 ]
    do
        if [[ "$1" =~ ^- ]]; then
            options=(${options[@]} "$1")
            shift
        else
            break
        fi
    done
    local message="$*"
    echo ${options[@]} "$message" 1>&2
}

# 標準エラー出力に時刻、スクリプト名付きで印字
function log() {
    local message="$*"
    local now="`date +'%Y-%m-%d %H:%M:%S'`"
    echo "$now $_script: $message" 1>&2
}

# バーバスモードなら標準エラー出力に時刻、スクリプト名付きで印字
function verbose_log() {
    local message="$*"
    if [ $_verbose -eq 1 ]; then
        local now="`date +'%Y-%m-%d %H:%M:%S'`"
        echo "$now $_script: $message" 1>&2
    fi
}

# 日本時間で日付を表示する
jdate () {
    TZ="Asia/Tokyo" date +'%Y-%m-%d %H:%M:%S %Z'
}

# 最初の引数が 2 番目以降の引数のリストに含まれるか
function member() {
    local needle="$1"
    shift
    local pos=0
    while [ 0 -lt $# ]
    do
        local elem="$1"
        if [ "$elem" = "$needle" ]; then
            echo $pos
            return 1
        fi
        let pos++
        shift
    done
    echo -1
    return 0
}

# 短い時間間隔でチェックしながら指定の時間だけプロセスが生成されるのを待つ
# wait_for_boot [-v] <コマンドライン> <プロセス id> <最大待機時間（ミリ秒）>
function wait_for_boot() {
    local verbose=0
    while [ 0 -lt $# ]
    do
        local arg="$1"
        if [[ "$arg" =~ ^- ]]; then
            local opt="${arg:1}"
            if [[ "$opt" =~ ^v ]]; then
                verbose=1
            else
                echo2 "wait_for_boot(): unknown option $arg"
                return 2
            fi
            shift
        else
            break
        fi
    done
    if [ $# -ne 3 ]; then
        echo2 "wait_for_boot(): illegal number of arguments"
        return 1
    fi
    if [[ ! "$2" =~ ^[1-9][0-9]* ]]; then
        echo2 "wait_for_boot(): illegal type of argument #2"
    fi
    if [[ ! "$3" =~ ^[1-9][0-9]* ]]; then
        echo2 "wait_for_boot(): illegal type of argument #3 to wait_for_boot()"
    fi
    local command="$1"                      # プロセスのコマンドライン
    local pid="$2"                          # プロセス id
    local max_wait="$3"                     # プロセスの起動を待機する時間の最大値。ミリ秒
    local interval=73                       # チェックの間隔。ミリ秒
    let local interval_u=$interval*1000     # チェックの間隔。マイクロ秒
    local current_wait=0                    # 現在までの待機時間。ミリ秒
    local check_count=0
    while [ $current_wait -lt $max_wait ]
    do
        let check_count++
        # $interval ミリ秒待つ
        usleep $interval_u
        # プロセスがあるか調べる
        local ps_output="`ps -p $pid -o pid=`"
        # プロセスがある
        if [ "$ps_output" != "" ]; then
            if [ $verbose -eq 1 ]; then
                echo2 "$command started successfully ($check_count)"
            fi
            return 0
        fi
        #echo2 "$current_wait"  流石にこれはうるさすぎ
        let current_wait=$current_wait+$interval
    done
    if [ $verbose -eq 1 ]; then
        echo2 "$command not found"
    fi
    return 1
}

function verbose_sleep() {
    local seconds="$1"
    local count=0
    while [ $count -lt $seconds ]
    do
        sleep 1
        let count++
        echo -ne '\r' 1>&2
        echo -n "sleeping $seconds seconds...$count" 1>&2
    done
    echo 1>&2
}

# 文字列 $1 の先頭から、文字列 $2 に含まれない文字だけで構成される部分文字列を取り出す
# 例）strcspn 'starship.jp' '.' => 'starship'
function strcspn() {
    local str="$1"
    local stoppers="$2"
    local spn="${str%%[${stoppers}]*}"
    echo "$spn"
}

# 全体で $1 桁になるように、$2 の頭に ' ' を付けて返す
function pad_space() {
    local width="$1"
    local n="$2"
    local digits=${#n}
    local let zeros=$width-$digits
    local pad='                '
    echo "${pad:0:$zeros}$n"
}

# 全体で $1 桁になるように、$2 の頭に適当な個数の $3 を付けて返す
function pad() {
    local width="$1"
    local n="$2"
    local p="$3"
    local digits=${#n}
    local let zeros=$width-$digits
    local padding="$p$p$p$p$p$p$p$p$p$p$p$p$p$p$p$p"
    echo "${padding:0:$zeros}$n"
}

# 文字列内の部分文字列をすべて別の文字列に置換する
# $1: どんな文字列を見つけるか
# $2: 見つけたらどんな文字列に置き換えるか
# $3: どんな文字列の中から見つけるか
# 例: Replace "foo" "FOO" "boo_foo_woo_boo_foo_woo"
# 返却値: "boo_FOO_woo_boo_FOO_woo"
function Replace() {
    local find="$1"
    local replace="$2"
    local subject="$3"
    local ret="${subject//$find/$replace}"
    echo "$ret"
}

# $1 で指定されたディレクトリ以下を再帰的にトラバースし、バックワードでカラのディレクトリを削除する。削除を実行するのがバックワードなので、削除した結果、親ディレクトリがカラになれば、親ディレクトリも削除できる。
# この関数でやろうとしたことは find で実現可能だった…。この関数要らん。
function DeleteEmptyDirectories() {
    local dir="$1"
    local files=(`ls -A1 $dir`)
    for file in ${files[@]}
    do
        local path="$dir/$file"
        if [ -d "$path" ]; then
            DeleteEmptyDirectories "$path"
            local status=$?
            if [ $status -eq 0 ]; then
                verbose_log "deleting $path"
                rmdir "$path"
            fi
        fi
    done
    local files=(`ls -A1 $dir`)
    if [ ${#files[@]} -eq 0 ]; then
        return 0
    else
        return 1
    fi
}

# ■プロセス間の排他制御
# 機能
#   指定された既存ファイルのシンボリック・リンク・ファイルを作成する。
#   シンボリックリンクは他のプロセスが作成済みでない場合に限り作成に成功する。
#   シェルスクリプトで「状態チェック」（「作成済みでない場合」）と「状態変更」（「作成する」）をアトミックに実行したいときの常套手段
# 引数
#   $1: ロックファイル（シンボリックリンク）のリンク元にするファイルのパス
#   $2: ブロック・フラグ。無指定または '0' なら 1 回ロックに失敗すると即失敗。それら以外ならロックできるまで永遠に試行を繰り返す
# 終了ステータス
#   0: ロックできた
#   1: ロックできなかった（非ブロックモードなので）
#   2: ロックできなかった（シンボリックリンク元のファイルが存在しないので）
function lock() {
    local file="$1"
    local block_flag="$2"
    local lock_file="$file.lock"
    if [ ! -e "$file" ]; then
        echo2 "$_script: $file not found"
        return 2
    fi
    while [ 0 -eq 0 ]
    do
        ln -s "$file" "$lock_file" > /dev/null 2>&1
        if [ $? -eq 0 ]; then
            break
        fi
        if [ "$block_flag" = '' -o "$block_flag" = '0' ]; then
            return 1
        fi
        sleep 1
    done
    return 0
}

function unlock() {
    local file="$1"
    local lock_file="$file.lock"
    unlink "$lock_file"
}

# バーバスモードなら標準エラー出力に印字
function verbose() {
    local message="$*"
    if [ $_verbose -eq 1 ]; then
        echo "$message" 1>&2
    fi
}

function get_pid() {
    local cmd="$1"
    local pids=(`pgrep -f "$cmd"`)  # -x を付けると引数付きのプロセスがマッチしなくなる！
    if [ ${#pids[@]} -eq 0 ]; then
        echo ''
    else
        echo "${pids[@]}"
    fi
}

function db_exists_() {
    local db_name="$1"
    cat <<EOS | psql -h $DB_HOST -U $DB_USER -t | grep $db_name | wc -l
\l $db_name
EOS
}

function db_exists() {
    local db_name="$1"
    local count=`db_exists_ $db_name`
    if [ $count -eq 0 ]; then
        return 0
    else
        return 1
    fi
}

########################################################################
# バランサー制御用関数

# LB ターゲットの状態
_LB_TARGET_STATUS_HEALTHY=0     # 健康
_LB_TARGET_STATUS_UNHEALTHY=1   # 不健康
_LB_TARGET_STATUS_DRAINING=2    # 登録解除中
_LB_TARGET_STATUS_UNUSED=3      # 登録されていない
_LB_TARGET_STATUS_INITIAL=4     # 登録中
_LB_TARGET_STATUS_UNKNOWN=9     # 不明

function RegisterInstanceToTargetGroup() {
    local target_group_name="$1"
    local target_group_arn="$2"
    local target_instance_name="$3"
    local target_instance_id="$4"
    aws elbv2 register-targets --target-group-arn $target_group_arn --targets Id=$target_instance_id
    status=$?
    if [ $status -ne 0 ]; then
        echo2 "can't register $target_instance_name"
        return 1
    fi
    return 0
}

function DeregisterInstanceFromTargetGroup() {
    local target_group_name="$1"
    local target_group_arn="$2"
    local target_instance_name="$3"
    local target_instance_id="$4"
    aws elbv2 deregister-targets --target-group-arn $target_group_arn --targets Id=$target_instance_id
    status=$?
    if [ $status -ne 0 ]; then
        echo2 "can't deregister $target_instance_name"
        return 1
    fi
    return 0
}

function IsInstanceHealthy() {
    local target_group_name="$1"
    local target_group_arn="$2"
    local target_instance_name="$3"
    local target_instance_id="$4"
    local output=(`aws elbv2 describe-target-health --target-group-arn $target_group_arn --targets Id=$target_instance_id --output text | egrep '^TARGETHEALTH[^0-9A-Za-z]'`)
    verbose "${output[@]}"
    if [ ${#output[@]} -eq 2 ]; then
        if [ ${output[1]} = 'healthy' ]; then
            return $_LB_TARGET_STATUS_HEALTHY
        fi
    elif [[ "${output[@]}" =~ unhealthy ]]; then
        return $_LB_TARGET_STATUS_UNHEALTHY
    elif [[ "${output[@]}" =~ draining ]]; then
        return $_LB_TARGET_STATUS_DRAINING
    elif [[ "${output[@]}" =~ unused ]]; then
        return $_LB_TARGET_STATUS_UNUSED
    elif [[ "${output[@]}" =~ initial ]]; then
        return $_LB_TARGET_STATUS_INITIAL
    fi
    return $_LB_TARGET_STATUS_UNKNOWN
}

# TIME_WAIT 状態のソケットが全て閉じられるまで待つ
function TimeWait() {
    local port="$1"
    local seconds=0
    while [ 1 ]
    do
        local time_wait_sockets=(`sudo netstat -anp | egrep ":${port}.*TIME_WAIT"`)
        if [ ${#time_wait_sockets[@]} -eq 0 ]; then
            break
        fi
        sleep 1
        let seconds++
        echo -ne '\r' 1>&2
        echo -n "$_script: waiting for $port TIME_WAIT sockets to be closed...$seconds" 1>&2
    done
    if [ 0 -lt $seconds ]; then
        echo2 ""
        echo2 "$_script: all $port TIME_WAIT sockets closed in $seconds seconds"
    else
        echo2 "$_script: no $port TIME_WAIT sockets found"
    fi
    return 0
}

# CUI 制御
MOVE_TO_COL="echo -en \\033[${RES_COL}G"
SETCOLOR_SUCCESS="echo -en \\033[1;32m"
SETCOLOR_FAILURE="echo -en \\033[1;31m"
SETCOLOR_WARNING="echo -en \\033[1;33m"
SETCOLOR_NORMAL="echo -en \\033[0;39m"

# 相対パスを絶対パスに変換する。絶対パスをそのまま返す。basename のファイルは存在しなくても良いが、その親ディレクトリは存在し、かつ、cd 可能でなければならない。
function get_absolute_path() {
    local path="$1"
    local dir="`dirname $path`"
    local base="`basename $path`"
    local cwd="`pwd`"
    if [ ! -d "$dir" ]; then
        echo2ex -e "get_absolute_path(): $dir not found.\npath: $path\ncwd: $cwd"
        return 1
    fi
    cd "$dir"
    if [ $? -ne 0 ]; then
        echo2ex -e "get_absolute_path(): can't cd to $dir"
        return 1
    fi
    local abs_dir="`pwd`"
    cd "$cwd"
    echo "$abs_dir/$base"
    return 0
}
