#!/bin/bash

cd "`dirname $0`"

source ~/bin/config.sh

back_dir='./tech-test-backend-main'
front_dir='./tech-test-frontendweb-main'

echo2 "<<<<<<< $back_dir >>>>>>>"
cd "$back_dir"
./control.sh "$1"
cd ..

echo2 "<<<<<<< $front_dir >>>>>>>"
cd "$front_dir"
./control.sh "$1"
