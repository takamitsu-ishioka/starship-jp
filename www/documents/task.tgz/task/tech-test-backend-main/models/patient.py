
from typing import List, Optional, Self

from lib.db import get_db
from lib.utils import bool_to_int
from models.medical_history import MedicalHistory
from models.medicine import Medicine

class Patient:
  def __init__(
    self, 
    id: Optional[int],
    name: str, 
    complaint: str, 
    medical_histories: List[MedicalHistory], 
    medicines: List[Medicine]
) -> None:
    
    self.id = id
    self.name = name
    self.complaint = complaint
    self.medical_histories = medical_histories
    self.medicines = medicines
  
  def dictionary(self):
    return {
      'id': self.id,
      'name': self.name,
      'complaint': self.complaint,
      'medical_histories': [x.dictionary() for x in self.medical_histories],
      'medicines': [x.dictionary() for x in self.medicines]
    }

  @classmethod
  def get_patient(cls, id: int) -> Self:
    db = get_db()
    cursor = db.cursor()
    result = cursor.execute('SELECT id, name, complaint FROM patient WHERE id=?', (id,))
    data = result.fetchone()
    
    patient = Patient(data[0], data[1], data[2], [], [])
    
    #result = cursor.execute('SELECT id, name, flag, user_id FROM medical_history WHERE user_id=?', (id,))
    result = cursor.execute('SELECT id, name, flag, user_id FROM medical_history WHERE user_id=? AND deleted=0', (id,))
    data = result.fetchall()

    #patient.medical_histories = [MedicalHistory(d[1], d[2], d[0], d[3]) for d in data]
    patient.medical_histories = [MedicalHistory(d[1], bool(d[2]), d[0], d[3]) for d in data]
    
    result = cursor.execute('SELECT id, name, user_id FROM medicine WHERE user_id=? AND deleted=0', (id,))
    data = result.fetchall()
    
    patient.medicines = [Medicine(d[1], d[0], d[2]) for d in data]
    
    return patient
  
  @classmethod
  def get_list(cls) -> List[Self]:
    db = get_db()
    cursor = db.cursor()
    result = cursor.execute('SELECT id, name, complaint FROM patient ORDER BY id')
    data = result.fetchall()
    
    return [Patient(d[0], d[1], d[2], [], []) for d in data]
    
  @classmethod
  def update(cls, id: int, json: dict):
    db = get_db()
    cursor = db.cursor()

    try:
      cursor.execute('BEGIN TRANSACTION trans1')
      cursor.execute('UPDATE patient SET name = ?, complaint = ? WHERE id = ?', (json['name'], json['complaint'], id))
      
      # 荒っぽいけど病歴はすべて洗い替えする
      cursor.execute('DELETE FROM medical_history WHERE user_id = ?', (id,))
      # 荒っぽいけど薬歴も洗い替えする
      cursor.execute('DELETE FROM medicine WHERE user_id = ?', (id,))
      
      for mh in json['medical_histories']:
        #cursor.execute('INSERT INTO medical_history (user_id, name, flag) VALUES (?, ?, ?)', (id, mh['name'], mh['flag']))
        cursor.execute('INSERT INTO medical_history (user_id, name, flag) VALUES (?, ?, ?)', (id, mh['name'], bool_to_int(mh['flag'])))

      for m in json['medicines']:
        cursor.execute('INSERT INTO medicine (user_id, name) VALUES (?, ?)', (id, m['name']))

      cursor.execute('COMMIT TRANSACTION trans1')
    except KeyError as e:
      cursor.execute('ROLLBACK TRANSACTION trans1')
      raise e
      
  @classmethod
  def create(cls, json: dict):
    db = get_db()
    cursor = db.cursor()

    try:
      cursor.execute('BEGIN TRANSACTION trans1')
      cursor.execute('INSERT INTO patient (name, complaint) VALUES (?, ?)', (json['name'], json['complaint']))
      
      last_id = cursor.lastrowid
      
      for mh in json['medical_histories']:
        cursor.execute('INSERT INTO medical_history (user_id, name, flag) VALUES (?, ?, ?)', (last_id, mh['name'], mh['flag']))

      for m in json['medicines']:
        cursor.execute('INSERT INTO medicine (user_id, name) VALUES (?, ?)', (last_id, m['name']))
      
      cursor.execute('COMMIT TRANSACTION trans1')
    except KeyError as e:
      cursor.execute('ROLLBACK TRANSACTION trans1')
      raise e
