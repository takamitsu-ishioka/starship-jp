#!/bin/bash

cd "`dirname $0`"

#source ~/bin/config.sh
source ./config.sh

_repo_base="`basename $_cwd`"

function usage() {
    local message="$*"
    cat <<USAGE 1>&2
$_script: $message
usage: $_script [-v(erbose)] <subcommand>
subcommands:
     start: start Web
      stop: stop Web
    status: show Web status
USAGE
    exit 1
}

function get_repo_procs() {
    local first_char="${_repo_base:0:1}"
    local rest="${_repo_base:1}"
    ps aux | grep "[$first_char]$rest" | grep -v 'vscode' | awk '{print $2}'
}

function start() {
    local pids=($(pgrep -f 'yarn dev'))
    if [ ${#pids[@]} -ne 0 ]; then
        log "web already running"
        return 1
    fi
    if [ ! -d ./logs ]; then
        mkdir ./logs
        if [ $? -ne 0 ]; then
            log "can't mkdir ./logs"
            return 1
        fi
    fi
    local now="`date +'%Y-%m-%dT%H:%M:%S'`"
    local log_file="./logs/$now"
    yarn dev > "$log_file" 2>&1 &
    sleep 3
    log "web started"
    #local node_pids=($(pgrep -f 'yarn dev') $(pgrep -f "$_repo_base"))
    local node_pids=($(pgrep -f 'yarn dev') $(get_repo_procs))
    if [ ${#node_pids[@]} -eq 0 ]; then
        log "can't start web"
        return 1
    fi
    node_pids="${node_pids[@]}"
    node_pids="${node_pids// /,}"
    #echo2 "ps -p $node_pids -o $_ps_columns"
    ps -p "$node_pids" -o "$_ps_columns"
    return 0
}

function stop() {
    #local pids=($(pgrep -f 'yarn dev') $(pgrep -f "$_repo_base"))
    local pids=($(pgrep -f 'yarn dev') $(get_repo_procs))
    if [ ${#pids[@]} -eq 0 ]; then
        log "no web processes found"
        return 1
    fi
    pids="${pids[@]}"
    local pid_csv="${pids// /,}"
    ps -p "$pid_csv" -o "$_ps_columns"
    log "kill -SIGINT $pids"
    #kill -SIGINT $pids
    kill -SIGTERM $pids
    local max_trial_count=30
    local trial_count=0
    while [ 1 ]
    do
        sleep 1
        #local pids_=($(pgrep -f 'yarn dev') $(pgrep -f "$_repo_base"))
        local pids_=($(pgrep -f 'yarn dev') $(get_repo_procs))
        if [ ${#pids_[@]} -eq 0 ]; then
            break
        fi
        pids_="${pids_[@]}"
        local pid_csv_="${pids_// /,}"
        ps -p "$pid_csv_" -o "$_ps_columns"
        let trial_count++
        if [ $trial_count -eq $max_trial_count ]; then
            log "can't kill $pids"
            return 1
        fi
    done
    log "killed $pids"
    return 0
}

function status() {
    #local pids=($(pgrep -f 'yarn dev') $(pgrep -f "$_repo_base"))
    local pids=($(pgrep -f 'yarn dev') $(get_repo_procs))
    if [ ${#pids[@]} -eq 0 ]; then
        log "no web processes found"
        return 1
    fi
    pids="${pids[@]}"
    pids="${pids// /,}"
    ps -p "$pids" -o "$_ps_columns"
    return 0
}

if [ $# -lt 1 ]; then
    usage 'too few arguments'
fi

command="$1"
shift

if [ "$command" = 'start' ]; then
    #pkill -f vscode-server # VSCode と yarn dev を同時に実行すると極めて高い確率で主記憶容量が不足し、load average 30 超えなどのとんでもない値になり、事実上使用不能の状態がしばらく続く。そうなると pkill すらできない。
    yarn cache clean
    start $*
elif [ "$command" = 'stop' ]; then
    stop
elif [ "$command" = 'status' ]; then
    status
else
    usage "unknown command $command"
fi

exit $?
