from flask import Flask, jsonify, g, request
from flask_cors import CORS
from models.patient import Patient
from models.medical_history import MedicalHistory
from models.medicine import Medicine

app = Flask(__name__)
CORS(app)

app.config['TRAP_HTTP_EXCEPTIONS']=True

import logging
logging.basicConfig(level=logging.DEBUG)

@app.teardown_appcontext
def close_connection(exception):
  db = getattr(g, '_db', None)
  if db is not None:
    db.close()

@app.route('/v1/list')
def list():
  patients = Patient.get_list()
  obj = [x.dictionary() for x in patients]
  return jsonify(obj)

@app.route('/v1/patient/<int:id>', methods=['GET', 'PUT'])
def patient(id: int):
  if request.method == 'GET':
    patient = Patient.get_patient(id)

    if patient is None:
      return jsonify({'error': 'Not Found'}), 404

    return jsonify(patient.dictionary())
  
  elif request.method == 'PUT':
    try:
      Patient.update(id, request.json)
    except KeyError as e:
      return jsonify({'error': "not found: %s" % (e.args[0],)}), 400
    
    return jsonify({'status': 'ok'})

  return jsonify({'error': 'method not allowed'}), 405

@app.route('/v1/patient/create', methods=['POST'])
def create():
  if request.method == 'POST':
    try:
      Patient.create(request.json)
    except KeyError as e:
      return jsonify({'error': "not found: %s" % (e.args[0],)}), 400
    
    return jsonify({'status': 'ok'})

  return jsonify({'error': 'method not allowed'}), 405

@app.route('/v1/patient/medical_history/create', methods=['POST'])
def create_medical_history():
    logging.debug(f"request.headers={request.headers}")
    logging.debug(f"request.json={request.json}")
    data = request.json
    patient_id = data.get('patient_id')
    medical_history = data.get('medical_history')

    if not patient_id or not medical_history:
      return jsonify({'error': 'Missing patient_id or medical_history data'}), 400

    try:
      create_medical_history = MedicalHistory.create(patient_id, medical_history)
      return jsonify(create_medical_history.dictionary()), 200
    except Exception as e:
      return jsonify({'error': f"Failed to create medical history: {e}"}), 400

@app.route('/v1/patient/medical_history/delete', methods=['POST'])
def delete_medical_history():
    logging.debug(f"request.headers={request.headers}")
    logging.debug(f"request.json={request.json}")
    data = request.json
    patient_id = data.get('patient_id')
    medical_history_id = data.get('medical_history_id')

    if not patient_id or not medical_history_id:
      return jsonify({'error': 'Missing patient_id or medical_history_id data'}), 400

    try:
      MedicalHistory.delete(patient_id, medical_history_id)
      return jsonify({'status': 'ok'})
    except Exception as e:
      return jsonify({'error': f"Failed to delete medical history: {e}"}), 400

@app.route('/v1/patient/medicine/create', methods=['POST'])
def create_medicine():
    logging.debug(f"request.headers={request.headers}")
    logging.debug(f"request.json={request.json}")
    data = request.json
    patient_id = data.get('patient_id')
    medicine = data.get('medicine')

    if not patient_id or not medicine:
      return jsonify({'error': 'Missing patient_id or medicine data'}), 400

    try:
      create_medicine = Medicine.create(patient_id, medicine)
      return jsonify(create_medicine.dictionary()), 200
    except Exception as e:
      return jsonify({'error': f"Failed to create medicine: {e}"}), 400

@app.route('/v1/patient/medicine/delete', methods=['POST'])
def delete_medicine():
    logging.debug(f"request.headers={request.headers}")
    logging.debug(f"request.json={request.json}")
    data = request.json
    patient_id = data.get('patient_id')
    medicine_id = data.get('medicine_id')

    if not patient_id or not medicine_id:
      return jsonify({'error': 'Missing patient_id or medicine_id data'}), 400

    try:
      Medicine.delete(patient_id, medicine_id)
      return jsonify({'status': 'ok'})
    except Exception as e:
      return jsonify({'error': f"Failed to delete medicine: {e}"}), 400

@app.errorhandler(Exception)
def error_handler(e):
    return jsonify({'error': str(e)}), e.code
