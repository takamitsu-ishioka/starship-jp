# 技術課題用のbackend

## 環境
- Python 3.11.5
- flask 3.0.2

## 基本的な使い方
- python 3.11系を用意する
- pip install -r requirements.txt
- flask --app main run
- http://127.0.0.1:5000 でサーバが動きます
