
from typing import Optional
from lib.db import get_db
import logging

logging.basicConfig(level=logging.DEBUG)

class Medicine:
  def __init__(self, name: str, id: Optional[int], user_id: Optional[int]) -> None:
    self.name = name
    self.id = id
    self.user_id = user_id
    
  def dictionary(self):
    return {
      'id': self.id,
      'name': self.name,
      'user_id': self.user_id
    }

  @classmethod
  def create(cls, patient_id: int, m: dict):
    logging.debug(f"patient_id={patient_id}")
    logging.debug(f"json={m}")
    db = get_db()
    cursor = db.cursor()

    try:
      result = cursor.execute(
        'INSERT INTO medicine (user_id, name) VALUES (?, ?) RETURNING *',
        (patient_id, m['name'])
      )
      row = result.fetchone()
      if not row:
        raise Exception(f"cannot insert medicine: {m}")
      id = row[0]
      user_id = row[1]
      name = row[2]
      created_m = Medicine(name, id, user_id)
      logging.debug(created_m.dictionary())
      db.commit()
      return created_m
    except KeyError as e:
      db.rollback()
      raise e
    except Exception as e:
      db.rollback()
      raise e

  @classmethod
  def delete(cls, patient_id: int, medicine_id: int):
    logging.debug(f"patient_id={patient_id}")
    logging.debug(f"medicine_id={medicine_id}")
    db = get_db()
    cursor = db.cursor()

    try:
      cursor.execute(
        'UPDATE medicine SET deleted = 1 WHERE id = ? AND user_id = ?',
        (medicine_id, patient_id)
      )
      db.commit()
    except KeyError as e:
      db.rollback()
      raise e
    except Exception as e:
      db.rollback()
      raise e
