import { MedicalHistory } from "./MedicalHistory"
import { Medicine } from "./Medicine"

/*
export interface PatientProps {
  id?: number
  name: string
  complaint: string
  medicines?: [Medicine]
  medicalHistories?: [MedicalHistory]
}

export class Patient {
  public id?: number
  public name: string
  public complaint: string
  public medicines?: [Medicine]
  public medicalHistories?: [MedicalHistory]

  constructor(init: PatientProps) {
    this.id = init.id
    this.name = init.name
    this.complaint = init.complaint
    this.medicalHistories = init.medicalHistories
    this.medicines = init.medicines
  }
}
*/

export interface PatientProps {
  id?: number
  name: string
  complaint: string
  medicines?: Medicine[]
  medicalHistories?: MedicalHistory[]
}

export class Patient {
  public id?: number
  public name: string
  public complaint: string
  public medicines?: Medicine[]
  public medicalHistories?: MedicalHistory[]

  constructor(init: PatientProps) {
    this.id = init.id
    this.name = init.name
    this.complaint = init.complaint
    this.medicalHistories = init.medicalHistories
    this.medicines = init.medicines
  }
}
